<?php get_header(); ?>

  <div class="container d-flex justify-content-between">
   <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Start Bootstrap </div>
      <div class="list-group list-group-flush">
        <?php
            if(is_active_sidebar('sidebar')):
           dynamic_sidebar('sidebar');
           endif;  
      ?>
        
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

   <div >

    <div class="row">
      <?php if(have_posts()) : ?> <!--  If there are posts available  -->
       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card" style="width: 18rem;">
              <div class="card-img-top">
                <?php if(has_post_thumbnail()) : ?>
                <?php the_post_thumbnail(); ?>
                <?php endif; ?>
              </div>
            <div class="card-body">
              <h5 class="card-title"><a href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
          <?php the_title(); ?>    <!--retrieves blog title-->
       </a></h5>
              <p class="card-text"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
              <p class="card-text"> <?php the_author(); ?></p><!--retrieves author of blog entry-->
              <p class="card-text"><?php the_excerpt(); ?></p><!--retrieves content-->
            </div>
          </div>
        </div>
        <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>  <!-- no posts found displayed -->
       <?php endif; ?> <!-- end if -->

    
    </div>
    
       
   </div>

  </div> 
<?php get_footer(); ?>