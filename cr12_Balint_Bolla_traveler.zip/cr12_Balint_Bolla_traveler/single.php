<?php get_header(); ?>
	
	<div class="container mt-5">

		<?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->

		<div>
			<h2><?php the_title(); ?>    <!--retrieves blog title--></h2>
		</div>
		<div class="small">
			<p>Posted on <?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
			<p>by <?php the_author(); ?></p><hr><!--retrieves author of blog entry-->
		</div>
		<div class="align-items-center">
			<div class="jumbotron jumbotron-fluid">
				<?php if(has_post_thumbnail()) : ?>
                <?php the_post_thumbnail(); ?>
                <?php endif; ?>
			</div>
			<div>
				<p><?php the_content(); ?></p><!--retrieves content-->
			</div>
		</div>
		

       
           

       
       
       

       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>
       <?php endif; ?> <!-- end if -->
	</div>

<?php get_footer(); ?>