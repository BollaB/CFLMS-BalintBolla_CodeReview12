	 <?php wp_footer(); ?>
	 <div class="bg-secondary text-center sticky-bottom mt-5 py-3">© 2020 Copyright:
		<p>Balint Bolla</p>
	 </div>
</body>

</html>