<?php get_header(); ?>

<div class="container">
    <div class="text-center mb-3">
    	<h1>Welcome!</h1>
    </div>    
	<div class="row">
	        
	                <img src="https://2nomads1narrative.files.wordpress.com/2011/03/everest-moon-bw.jpg" class="col-12">
	</div>

        
</div>

<?php get_footer(); ?>